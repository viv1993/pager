package com.practice.demo;
import java.util.*;

public class DominoPiling {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int t = sc.nextInt();
		
		String str = sc.nextLine();		
		char ch[] = str.toCharArray();
		
//		for(int i = 0 ; i < n ; i++) {
//			 ch[i] = sc.next().charAt(i);
//		}
		
		for(int i  = 0 ; i < t ; i++)
		{
			for(int j = 0 ; j< ch.length-1 ; j++)
			{
				if(ch[j] == 'B' && ch[j+1] == 'G')
				{
					char s = ch[j];
					ch[j] = ch[j+1];
					ch[j+1] = s;
					j++;
				
					
				}
			}
			
		}
//		for (int i = 0; i < ch.length; i++) { 
//			
//		}
		
		String str1 = String.valueOf(ch);
		System.out.print("dsfdsf"+str1);
		
		sc.close();

	}

}