package com.practice.demo;

import java.util.LinkedList;
import java.util.Queue;

public class ThreadTest {

	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<Integer>();
		PC<Integer> pc = new PC(queue, 3);
		
		new Thread(() -> {
			try {
				pc.produce();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).start();
		
		new Thread(() -> {
			try {
				pc.consume();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).start();
	}
	
}

class PC<E> {
	
	Queue<E> queue;
	int capacity;
	
	public PC(Queue<E> q, int c) {
		this.queue = q;
		this.capacity = c;
	}
	
	public void produce() throws InterruptedException {
		synchronized (queue) {
			for(int i=0;i<10;i++) {
				if(queue.size() == capacity) {
					System.out.println(Thread.currentThread() + " is in waiting state");
					queue.wait();
				} else {
					System.out.println(Thread.currentThread() + " has produced value " + i);
					queue.add((E)(new Integer(i)));
					queue.notify();
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
				}
			}
		}
	}
	
	public void consume() throws InterruptedException {
		synchronized (queue) {
			for(int i=0;i<10;i++) {
				if(queue.size() == 0) {
					System.out.println(Thread.currentThread() + " is in waiting state");
					queue.wait();
				} else {
					Integer val = (Integer) queue.poll();
					queue.notify();
					System.out.println(Thread.currentThread() + " has consumed value: " + val);
					try {
						Thread.sleep(2000);
					} catch (Exception e) {
					}
				}
			}
		}
	}
}