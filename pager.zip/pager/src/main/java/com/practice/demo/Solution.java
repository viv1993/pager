package com.practice.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

class Solution {
	List<List<Integer>> res = new ArrayList<>();
	List<Integer> list = new ArrayList<>();
	static String  regex = "^0+(?!$)";
	private static int k = 1702766719;

	public static void main(String[] args) {
		Solution obj = new Solution();
//		obj.combinationSum(new int[] {2,3,4,7}, 7);
		String num = "1001";
//		System.out.println(num.replaceAll(regex, ""));
//		obj.removeKdigits(num, 1);
		int a = '9';
		System.out.println(a);
		findlocation();
//		obj.minimumDeviation(new int[] {2,10,8});
		System.out.println(firstBadVersion());
		
	}
	
	public static int majorityElement(int[] nums) {
//        Arrays.sort(nums);
//        int n = nums.length;
//        for(int i=0;i<n;i++) {
//        	if(nums[i] == nums[i + n/2]) {
//        		return nums[i];
//        	}
//        }
//        return -1;
		int c=-1; // keep a count to keep freq of element
        int maj = -1; // stores the potential majority
        for(int n : nums)
        {
            if(c<=0) // if freq becomes zero consider the curr element as majority
            {
                maj = n;
                c=1;
                continue;
            }
            if(n==maj) c++; // if n is same as what we assumed majority
            else c--; // if n is different to what we assumed as majority
        }
        return maj;
    }
	
	public static void removeCoveredPair() {
		int arr[][] = {{3,10},
				{4,10},
				{5,11}
				};
	
		Arrays.sort(arr, (int[] o1, int[] o2) -> o2[0]-o1[0]);
		Arrays.stream(arr).forEach((int x[]) -> {
			System.out.println(); 
			Arrays.stream(x).forEach(y -> System.out.print(y + " "));
			});
		
		int res = arr.length;
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i][1] <= arr[j][1]) {
					res--;
					break;
				}
			}
		}
		
		
		System.out.println(res);
	}
	
	public static void findlocation() {
		String str = "GGBGBGGBG";
		int t = 1;
		int prev = -3;
		char a[] = str.toCharArray();
		for(int i=0;i<str.length();i++) {
			if(a[i] == 'B') {
				prev = i;
				t=1;
			}
			if(a[i] == 'G' && i == prev+1 && t>0) {
				char c = a[i];
				a[i] = a[prev];
				a[prev] = c;
				t--;prev++;
			}
		}
		
		System.out.println(new String(a));
		
	}

	public List<List<Integer>> combinationSum(int[] candidates, int target) {

		findSumCombinations(candidates, target);
		return null;
	}

	public String removeKdigits(String num, int k) {

		int n = num.length(), j = 0;
		int rd = n - k;
		int min = Integer.MAX_VALUE;
		String res = "";
		while (rd > 0) {
			min = Integer.MAX_VALUE;
			for (int i = j; i < n; i++) {
				int t = Character.getNumericValue(num.charAt(i));
				if (t < min && (n - i) >= rd) {
					min = t;
					j = i+1;
				}
			}
			rd--;
			res = res + min;
		}

		return res;
	}

//2,3,6,7
	public void findSumCombinations(int a[], int k) {
		if (k == 0) {
			print(list);
			return;
		} else if (k < 0) {
			return;
		}
		for (int j = 0; j < a.length; j++) {
			list.add(a[j]);
			findSumCombinations(a, k - a[j]);
			if (list.size() > 0)
				list.remove(list.size() - 1);
		}
		return;
	}

	private void print(List<Integer> list) {
		System.out.println();
		for (Integer val : list) {
			System.out.print(val + " ");
		}
	}
	
	public int minimumDeviation(int[] nums) {
        
        PriorityQueue<Integer> queue = new PriorityQueue<>((a,b) -> b-a);
        int min = Integer.MAX_VALUE;
        for(Integer val : nums) {
            if(val%2 != 0) {
                val = val*2;
            }
            min = Math.min(val, min);
            queue.add(val);
        }
        
        int d = Integer.MAX_VALUE;
        while(queue.peek()%2==0) {
            int max = queue.remove();
            d = Math.min(d, max - min);
            min = Math.min(min, max/2);
            queue.add(max/2);
        }

        return Math.min(d, queue.peek()-min);
    }
	
	public static  int search() {
        int nums[] = {5};
        int target = 5;
        int beg = 0, end = nums.length-1;
        while(beg<=end) {
        	int mid = (end + beg)/2;
        	if(nums[mid] == target) {
        		return mid;
        	} 
        	if(nums[mid] > target) {
        		end = mid-1;
        	} else {
        		beg = mid+1;
        	}
        }
        return -1;
    }
	
	public static int firstBadVersion() {
		int n = 2126753390;
        long beg = 0, end=n;
        int m = -1, res=0;
        while(beg<=end) {
            m = (int) ((end+beg)/2);
            if(isBadVersion(m)) {
            	end = m-1;
            	res = m;
            }
            else if(!isBadVersion(m)) {
            	beg = m+1;
            }
        }
        return res;
    }
	
	public static boolean isBadVersion(int i) {
		if(i>=k )
			return true;
		return false;
	}
}