package com.practice.demo;

import java.io.UnsupportedEncodingException;

public class MReference {
	
	private String str;
	
	public void setStr(String str) {
		this.str = str;
	}
	
	public String getStr() {
		return str;
	}

	public static void main(String[] args) throws UnsupportedEncodingException {

//		String str = "%7B%22attempts%22%3A%220%22%2C%22status%22%3A%22NOT_TRIED%22%2C%22properties%22%3A%7B%22update.customer%22%3Atrue%2C%22migrate.customer%22%3Atrue%7D%2C%22customerAndCallbackRecords%22%3A%5B%7B%22customerRecord%22%3A%7B%22projectcount%22%3A0%2C%22city%22%3A%22Patna%22%2C%22impact%22%3A%22N%22%2C%22batch%22%3A324%2C%22locality%22%3A%22Darbhanga%22%2C%22propertytype%22%3A%22Multistorey+Apartment%2CBuilder+Floor+Apartment%2CPenthouse%2CStudio+Apartment%22%2C%22max_budget%22%3A%225600000%22%2C%22projectids%22%3A%22NA%22%2C%22buyerid%22%3A11130457%2C%22priority%22%3A5%2C%22data_source%22%3A%22BATCH_FAIL%22%2C%22phone1%22%3A%22eg6NFx%252Bt0iEcMDA%2FRPM5CA%3D%3D%22%2C%22iCalll%22%3A%22N%22%2C%22min_budget%22%3A%225600000%22%2C%22name%22%3A%22+%22%2C%22rank%22%3A%2218%22%2C%22suburb%22%3A%22NA%22%2C%22tag%22%3A%22Low%22%2C%22update_date_time%22%3A%222021-11-03+11%3A48%3A44%22%2C%22email%22%3A%22dYoQd8wxxiUSBd0yeXs5tdKjywoOlYJf%22%2C%22budget%22%3A5600000%2C%22propertyfor%22%3A%22S%22%7D%7D%5D%2C%22callbackRecord%22%3A%7B%7D%2C%22campaignId%22%3A139%2C%22leadId%22%3A1253%7D";
//		String json = URLDecoder.decode(str, StandardCharsets.UTF_8.toString());
//		System.out.println(json);
		String str = "Java is a programming Language";
		System.out.println(reverseWords(str.toCharArray()));
	}
	
	public static String reverseWords(char[] value) {
		int beg=0, end = 0;
		for(int i=0;i < value.length;i++) {
			if(value[i] == ' ' || i == value.length) {
				end = i;
				reverse(value, beg, end - 1);
				beg = i+1;
			} 
		}
		
		beg = 0;
		end = value.length - 1;
		reverse(value, beg, end);		return new String(value);
	}

	private static void reverse(char[] value, int beg, int end) {
		
		while(beg < end) {
			char t = value[beg];
			value[beg] = value[end];
			value[end] = t;
			end--;
			beg++;
		}
	}

}

class B implements A {
	
	@Override
	public String getResult(String str, int num) {
		return "Length:" + (str.length() + num);
	}

	@Override
	public String getResult(String str) {
		return this.getResult(str, 0);
	}
}

interface A {
	String getResult(String str, int num);
	String getResult(String str);
}