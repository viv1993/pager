package com.practice.demo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LinkedListdemo {
	public static String str = "";
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		LinkedListdemo obj = new LinkedListdemo();
		ListNode node = new ListNode(1);
//		obj.sortList(node);
//		obj.reverseWords();
//		obj.removeNthFromEnd(node, 1);
//		System.out.println(obj.lengthOfLongestSubstring());
//		System.out.println(obj.checkInclusion("ab", "eidboaoo"));
//		int grid[][] = {{0,0,1,0,0,0,0,1,0,0,0,0,0},{0,0,0,0,0,0,0,1,1,1,0,0,0},
//				{0,1,1,0,1,0,0,0,0,0,0,0,0},{0,1,0,0,1,1,0,0,1,0,1,0,0},
//				{0,1,0,0,1,1,0,0,1,1,1,0,0},{0,0,0,0,0,0,0,0,0,0,1,0,0},{0,0,0,0,0,0,0,1,1,1,0,0,0},
//				{0,0,0,0,0,0,0,1,1,0,0,0,0}};
//		System.out.println(obj.maxAreaOfIsland(grid));
		System.out.println(5&5);
		ExecutorService executors = Executors.newFixedThreadPool(4);
		System.out.println(Thread.currentThread() + ": "  +(executors.submit(() -> {System.out.println(Thread.currentThread() + ": Inside thread implementation");
								return 1;
			})).get());
		
	}
	
	public String bin(int n) {
        if(n>1)
            bin(n/2);
        return str = str + n%2;
    }
	
	public int maxAreaOfIsland(int[][] grid) {
        int r = grid.length;
        int max = 0;
        for(int i=0;i<grid.length;i++) {
            int c = grid[i].length;
            for(int j=0;j<c;j++) {
                int res = findMaxArea(i, j, r, c, grid);
                if(res > max )
                    max = res;
            }
        }
        Queue<ListNode> queue = new LinkedList<>();
        return max;
    }
    
    public int findMaxArea(int i, int j, int r, int c, int a[][]) {
        if(i<r && i>=0 && j<c && j>=0 && a[i][j] == 1) {
        	a[i][j] = 0;
            return 1 + findMaxArea(i+1, j, r, c, a) + findMaxArea(i-1, j, r, c, a) + findMaxArea(i, j+1, r, c, a) + findMaxArea(i, j-1, r, c, a);
        }
        
        return 0;
    }

	public boolean checkInclusion(String s1, String s2) {

		Map<Character, Integer> s1Map = new HashMap<>();
		for (int i = 0; i < s1.length(); i++) {
			s1Map.put(s1.charAt(i), s1Map.getOrDefault(s1.charAt(i), 0) + 1);
		}

		for (int i = 0; i <= s2.length() - s1.length(); i++) {
			Map<Character, Integer> s2Map = new HashMap<>();
			for (int j = 0; j < s1.length(); j++) {
				s2Map.put(s2.charAt(i+j), s2Map.getOrDefault(s2.charAt(i+j), 0) + 1);
			}
            boolean flag = true;
            for (char key: s1Map.keySet()) {
            if (s1Map.get(key) - s2Map.getOrDefault(key, -1) != 0)
                    flag = false;
                    break;
            }
            if(flag)
                return true;
		}
		return false;
	}

	public int lengthOfLongestSubstring() {
		String s = "abba";
		Map<Character, Integer> map = new HashMap<>();
		int l = 0, r = 0, n = s.length(), res = 0;
		while (r < n) {
			char c = s.charAt(r);
			if (map.containsKey(c))
				l = Math.max(map.get(c) + 1, l);
			map.put(c, r);
			int len = r - l + 1;
			if (res < len)
				res = len;
			r++;
		}
		return res;
	}

	public ListNode sortList(ListNode head) {
		Set<ListNode> set = new TreeSet<>((ListNode o1, ListNode o2) -> o1.val - o2.val);
		ListNode temp = head;
		while (temp != null) {
			set.add(temp);
			temp = temp.next;
		}
		int i = 0;
		ListNode t = null;
		for (ListNode node : set) {
			if (i++ == 0) {
				temp = node;
				t = temp;
				continue;
			}
			temp.next = node;
			temp = temp.next;
		}
		temp.next = null;
		return t;
	}

	public String reverseWords() {
		String s = "Let's take LeetCode contest";
		int i = 0;
		char str[] = s.toCharArray();
		int j = str.length - 1;
		while (i < j) {
			char c = str[i];
			str[i] = str[j];
			str[j] = c;
			i++;
			j--;
		}
		StringBuilder sb = new StringBuilder();
		sb.insert(0, 'c');
		sb.insert(0, 'b');
		return new String(str);
	}

	public ListNode removeNthFromEnd(ListNode head, int n) {

		ListNode slow = head, fast = head;
		int i = 0;
		while (fast.next != null) {
			if (i++ >= n)
				slow = slow.next;
			fast = fast.next;
		}
		if (slow.next != null && slow.next.next != null)
			slow.next = slow.next.next;
		else {
			ListNode t = slow;
			slow = slow.next;
			t.next = null;
		}
		return head;
	}

	public int compareVersion() {

		String a[] = "0.1".split("\\.");
		String b[] = "1.1".split("\\.");

		int i = 0, j = 0;
		int res = 0;
		while (i < a.length && j < b.length) {
			if (Integer.parseInt(a[i]) < Integer.parseInt(b[i])) {
				res = -1;
				i++;
				j++;
				break;
			} else if (Integer.parseInt(a[i]) > Integer.parseInt(b[i])) {
				res = 1;
				i++;
				j++;
				break;
			} else {
				i++;
				j++;
			}
			System.out.println(res);
		}

		return res;
	}
}

class ListNode {
	int val;
	ListNode next;

	ListNode() {
	}

	ListNode(int val) {
		this.val = val;
	}

	ListNode(int val, ListNode next) {
		this.val = val;
		this.next = next;
	}
}
