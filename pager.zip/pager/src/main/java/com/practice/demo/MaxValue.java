package com.practice.demo;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface MaxValue {

	int value() default 0;
}

class TestAnnotation {
	@MaxValue(10)
	private int a;
	
	public static void main(String[] args) throws NoSuchFieldException, SecurityException {
		TestAnnotation obj = new TestAnnotation();
		Field f = obj.getClass().getDeclaredField("a");
		
		System.out.println(f.getAnnotation(MaxValue.class).value());
	}
}
