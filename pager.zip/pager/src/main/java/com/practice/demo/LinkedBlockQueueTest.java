package com.practice.demo;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;

public class LinkedBlockQueueTest {
	
	public static void main(String[] args) {
		PCTest obj = new PCTest();
		
		new Thread(() -> {
			try {
				obj.produce();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).start();
		
		new Thread(() -> {
			try {
				obj.consume();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
	}
}

class PCTest {
	BlockingDeque<Integer> queue = (BlockingDeque<Integer>) new ArrayBlockingQueue(4);
	int capacity = 4;
	int val = 0;
	
	public void produce() throws InterruptedException {
		while(queue.size() < 4) {
			try {
				Thread.sleep(500);
			} catch (Exception e) {
				// TODO: handle exception
			}
			System.out.println(Thread.currentThread() + " has created value : "+val);
			queue.put(val);
		}
	}
	
	public void consume() throws InterruptedException {
		while(queue.size() > 0) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
			int val = queue.take();
			System.out.println(Thread.currentThread() + " has consumed  value : "+val);
		}
	}
}
