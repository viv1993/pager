package com.testproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.testproject.model.Team;
import com.testproject.service.PagerService;

@RestController
@RequestMapping("/pagerApi")
public class PagerController {

	@Autowired
	private PagerService pagerService;
	
	@PostMapping(value = "/createTeam")
	@ResponseBody
	public Team createTeam(Team team) {
		return pagerService.createTeam(team);
	}
	
	public String receiveAlert(@RequestParam(name = "team_id") int teamId) {
		pagerService.receiveAlert(teamId);
		return null;
	}
	
}
