package com.testproject.service;

import com.testproject.model.Team;

public interface PagerService {

	public Team createTeam(Team team);
	
	public void receiveAlert(int teamId);
}
