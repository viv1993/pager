package com.testproject.service;

import org.springframework.data.repository.CrudRepository;

import com.testproject.model.Team;

public interface TeamRepo extends CrudRepository<Team, Integer>{

}
