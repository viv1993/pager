package com.testproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.testproject.model.Developer;
import com.testproject.model.Team;

@Service
public class PagerServiceImpl implements PagerService {
	
	private final static String NOTIFICATION_URL = "";
	
	@Autowired
	private TeamRepo teamRepo;

	@Override
	public Team createTeam(Team team) {
		if(team == null)
			return null;
		return teamRepo.save(team);
	}

	@Override
	public void receiveAlert(int teamId) {
		Optional<Team> team = teamRepo.findById(teamId);
		Team teamObj = null;
		if(team.isPresent()) 
			teamObj = team.get();
		
		List<Developer> devs = teamObj.getDevelopers();
		if(devs != null && devs.size() > 0) {
			int devPos = (int) (Math.random()%(devs.size()-1));
			Developer dev = devs.get(devPos);
			if(dev != null) {
				RestTemplate restTemplate = new RestTemplate();
				JSONPObject notificationObj = getNotificationObj(dev);
				ResponseEntity<Object> res = restTemplate.postForEntity(NOTIFICATION_URL, notificationObj, null);
				if(res.getStatusCode() == HttpStatus.OK) {
					System.out.println(res.getBody());
				}
			}
		}
	}

	private JSONPObject getNotificationObj(Developer dev) {
		return null;
	}

}
